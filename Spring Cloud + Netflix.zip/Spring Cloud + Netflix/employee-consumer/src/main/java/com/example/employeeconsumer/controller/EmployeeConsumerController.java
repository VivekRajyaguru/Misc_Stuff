package com.example.employeeconsumer.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.cloud.client.loadbalancer.LoadBalancerClient;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.example.employeeconsumer.service.proxy.EmployeeProducerProxy;
import com.example.model.Employee;

@RestController

public class EmployeeConsumerController {

	@Autowired
	private DiscoveryClient discoveryClient;
	
	@Autowired
	private LoadBalancerClient loadBalancer;

	@Autowired
	private EmployeeProducerProxy employeeProducerProxy;

	@GetMapping("/get")
	public ResponseEntity<Employee> get() {
		List<ServiceInstance> instances = discoveryClient.getInstances("employee-producer");
		ServiceInstance serviceInstance = instances.get(0);

		String baseUrl = serviceInstance.getUri().toString();

		baseUrl = baseUrl + "/employee";

		System.out.println("Url : " + baseUrl);

		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<Employee> response = null;
		response = restTemplate.exchange(baseUrl, HttpMethod.GET, getHeaders(), Employee.class);
		return response;
	}
	
	@GetMapping("/getByLoadBalancere")
	public ResponseEntity<Employee> getByLoadBalancere(){
		
		ServiceInstance serviceInstance=loadBalancer.choose("employee-producer");
		
		System.out.println(serviceInstance.getUri());
		
		String baseUrl=serviceInstance.getUri().toString();
		
		baseUrl=baseUrl+"/employee";
		System.out.println("Url : " + baseUrl);

		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<Employee> response = null;
		response = restTemplate.exchange(baseUrl, HttpMethod.GET, getHeaders(), Employee.class);
		return response;
	}

	@GetMapping("/getByFeign")
	public ResponseEntity<Employee> getByFeign() {
		return employeeProducerProxy.get();
	}

	private static HttpEntity<?> getHeaders() {
		HttpHeaders headers = new HttpHeaders();
		headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
		return new HttpEntity<>(headers);
	}

	

}
