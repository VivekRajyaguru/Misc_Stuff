package com.example.employeeconsumer.service.proxy;

import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;

import com.example.model.Employee;

@FeignClient("EMPLOYEE-PRODUCER")
@RibbonClient("EMPLOYEE-PRODUCER")
public interface EmployeeProducerProxy {

	@GetMapping("/employee")
	public ResponseEntity<Employee> get();
}
