package com.example.employeeproducer.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.employeeproducer.model.Employee;

@RestController
@RequestMapping("/employee")
public class EmployeeProducerController {
	
	@GetMapping
	public ResponseEntity<Employee> get() {
		Employee emp = new Employee();
		emp.setFirstName("Imran");
		emp.setLastName("Momin");
		emp.setDesignation("Software Engineer");
		emp.setEmployeeId(683);
		return new ResponseEntity<Employee>(emp, HttpStatus.OK);
	}
	
}
